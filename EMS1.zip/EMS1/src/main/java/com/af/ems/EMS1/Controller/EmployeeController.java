package com.af.ems.EMS1.Controller;

import com.af.ems.EMS1.DTO.EmployeeDTO;
import com.af.ems.EMS1.Entity.Employee;
import com.af.ems.EMS1.Exception.ResourceNotFoundException;
import com.af.ems.EMS1.Service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;

@RestController
@RequestMapping("/api/employees")
@CrossOrigin(origins = "http://localhost:3000")
public class EmployeeController {
    @Autowired
    private EmployeeService employeeService;

    @PostMapping("/create")
    public ResponseEntity<Employee> createEmployee(@ModelAttribute EmployeeDTO employeeDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return ResponseEntity.badRequest().build();
        }

        try {
            Employee employee = convertToEmployeeEntity(employeeDTO);
            Employee savedEmployee = employeeService.saveEmployee(employee, employeeDTO.getPhoto());
            return ResponseEntity.ok(savedEmployee);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    // Helper method to convert EmployeeDTO to Employee entity
    private Employee convertToEmployeeEntity(EmployeeDTO employeeDTO) {
        Employee employee = new Employee();
        // Set fields from DTO to entity
        employee.setEmployeeId(employeeDTO.getEmployeeId());
        employee.setName(employeeDTO.getName());
        employee.setEmail(employeeDTO.getEmail());
        employee.setDepartmentName(employeeDTO.getDepartmentName());
        employee.setDesignation(employeeDTO.getDesignation());
        employee.setEmploymentType(employeeDTO.getEmploymentType());
        employee.setEmployeeStatus(employeeDTO.getEmployeeStatus());
        employee.setSourceOfHire(employeeDTO.getSourceOfHire());
        employee.setDateOfJoining(employeeDTO.getDateOfJoining());
        employee.setPhoneNumber(employeeDTO.getPhoneNumber());
        employee.setAddress(employeeDTO.getAddress());
        employee.setAadhaar(employeeDTO.getAadhaar());
        employee.setCtc(employeeDTO.getCtc());
        employee.setPassword(employeeDTO.getPassword());
        return employee;
    }

    @GetMapping
    public List<Employee> getAllEmployees() {
       return employeeService.getAllEmployees();
    }
    @GetMapping("/{id}")
    public Employee getEmployeeById(@PathVariable Long id) {
        return employeeService.getEmployeeById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + id));
    }
    @DeleteMapping("/{id}")
    public void deleteEmployee(@PathVariable Long id) {
        employeeService.deleteEmployee(id);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Employee> updateEmployee(@PathVariable Long id, @ModelAttribute EmployeeDTO employeeDTO, BindingResult bindingResult) {
        if (bindingResult.hasErrors()) {
            return ResponseEntity.badRequest().build();
        }

        try {
            Employee existingEmployee = employeeService.getEmployeeById(id)
                    .orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + id));

            // Update fields from DTO to existing entity
            existingEmployee.setEmployeeId(employeeDTO.getEmployeeId());
            existingEmployee.setName(employeeDTO.getName());
            existingEmployee.setEmail(employeeDTO.getEmail());
            existingEmployee.setDepartmentName(employeeDTO.getDepartmentName());
            existingEmployee.setDesignation(employeeDTO.getDesignation());
            existingEmployee.setEmploymentType(employeeDTO.getEmploymentType());
            existingEmployee.setEmployeeStatus(employeeDTO.getEmployeeStatus());
            existingEmployee.setSourceOfHire(employeeDTO.getSourceOfHire());
            existingEmployee.setDateOfJoining(employeeDTO.getDateOfJoining());
            existingEmployee.setPhoneNumber(employeeDTO.getPhoneNumber());
            existingEmployee.setAddress(employeeDTO.getAddress());
            existingEmployee.setAadhaar(employeeDTO.getAadhaar());
            existingEmployee.setCtc(employeeDTO.getCtc());
            existingEmployee.setPassword(employeeDTO.getPassword());

            // Save updated employee including photo upload if provided
            Employee updatedEmployee = employeeService.saveEmployee(existingEmployee, employeeDTO.getPhoto());
            return ResponseEntity.ok(updatedEmployee);
        } catch (IOException e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

    @GetMapping("/departments")
    public ResponseEntity<List<String>> getAllDepartments() {
        List<String> departments = employeeService.getAllDepartments();
        return ResponseEntity.ok(departments);
    }
}
