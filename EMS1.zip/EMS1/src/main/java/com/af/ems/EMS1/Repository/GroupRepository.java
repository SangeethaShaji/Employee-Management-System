package com.af.ems.EMS1.Repository;

import com.af.ems.EMS1.Entity.Groupp;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface GroupRepository extends JpaRepository<Groupp, Long> {

    Optional<Groupp> findByName(String name);

}
