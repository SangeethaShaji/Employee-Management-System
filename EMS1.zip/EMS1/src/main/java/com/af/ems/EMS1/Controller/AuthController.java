package com.af.ems.EMS1.Controller;


import com.af.ems.EMS1.DTO.EmployeeDTO;
import com.af.ems.EMS1.DTO.ResetPasswordForm;
import com.af.ems.EMS1.DTO.ResetPasswordRequest;
import com.af.ems.EMS1.Entity.Employee;
import com.af.ems.EMS1.Entity.PasswordResetToken;
import com.af.ems.EMS1.Repository.EmployeeRepository;
import com.af.ems.EMS1.Repository.PasswordResetTokenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {

    @Autowired
    private PasswordResetTokenRepository tokenRepository;

    @Autowired
    private EmployeeRepository employeeRepository;


    @GetMapping("/reset-password")
    public ResponseEntity<?> resetPasswordForm(@RequestParam String token) {
        PasswordResetToken resetToken = tokenRepository.findByToken(token);
        if (resetToken == null || resetToken.getExpiryDate().isBefore(LocalDateTime.now())) {
            return ResponseEntity.badRequest().body("Invalid or expired token");
        }

        // Return the form with the email pre-filled
        return ResponseEntity.ok(new ResetPasswordForm(resetToken.getEmail()));
    }

    @PostMapping("/reset-password")
    public ResponseEntity<?> resetPassword(@RequestBody ResetPasswordRequest request) {
        PasswordResetToken resetToken = tokenRepository.findByToken(request.getToken());
        if (resetToken == null || resetToken.getExpiryDate().isBefore(LocalDateTime.now())) {
            return ResponseEntity.badRequest().body("Invalid or expired token");
        }

        // Validate and update password
        if (!request.getPassword().equals(request.getConfirmPassword())) {
            return ResponseEntity.badRequest().body("Passwords do not match");
        }

        // Update employee password
        Employee employee = employeeRepository.findByEmail(resetToken.getEmail());
        employee.setPassword(request.getPassword()); // Directly setting the password
        employeeRepository.save(employee);

        // Delete the token
        tokenRepository.delete(resetToken);

        return ResponseEntity.ok("Password reset successful");
    }

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody EmployeeDTO employeeDTO) {
        Employee employee = employeeRepository.findByEmail(employeeDTO.getEmail());
        if (employee != null && employee.getPassword().equals(employeeDTO.getPassword())) {
            // Add any additional authentication logic here, such as token generation
            return ResponseEntity.ok("Login successful");
        } else {
            return ResponseEntity.badRequest().body("Invalid email or password");
        }
    }

}
