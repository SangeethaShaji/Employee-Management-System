package com.af.ems.EMS1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ems1Application {

	public static void main(String[] args) {
		SpringApplication.run(Ems1Application.class, args);
	}

}
