package com.af.ems.EMS1.Controller;

import com.af.ems.EMS1.DTO.AddEmployeeRequest;
import com.af.ems.EMS1.Entity.Employee;
import com.af.ems.EMS1.Entity.GroupRequest;
import com.af.ems.EMS1.Entity.Groupp;
import com.af.ems.EMS1.Exception.ResourceNotFoundException;
import com.af.ems.EMS1.Repository.GroupRepository;
import com.af.ems.EMS1.Service.GroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/groups")
@CrossOrigin(origins = "http://localhost:3000")
public class GroupController {
    @Autowired
    private GroupService groupService;


    @PostMapping
    public Groupp createGroup(@RequestBody GroupRequest groupRequest) {
        return groupService.createGroup(groupRequest);
    }
    @PostMapping("/addEmployee")
    public void addEmployeeToGroup(@RequestBody AddEmployeeRequest request) {
        groupService.addEmployeeToGroup(request.getEmployeeId(), request.getGroupName());
    }
    @GetMapping
    public List<Groupp> getAllGroups() {
        return groupService.getAllGroups();
    }
    @GetMapping("/{id}")
    public Groupp getGroupById(@PathVariable Long id) {
        return groupService.getGroupById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Group not found for this id :: " + id));
    }
    @PutMapping("/{id}")
    public Groupp updateGroup(@PathVariable Long id, @RequestBody GroupRequest groupRequest) {
        return groupService.updateGroup(id, groupRequest);
    }
    @DeleteMapping("/{id}")
    public void deleteGroup(@PathVariable Long id) {
        groupService.deleteGroup(id);
    }
    @GetMapping("/{groupName}/employees")
    public List<Employee> getEmployeesByGroupName(@PathVariable String groupName) {
        return groupService.getEmployeesByGroupName(groupName);
    }

    @DeleteMapping("/{groupName}/employees/{employeeId}")
    public void removeEmployeeFromGroup(@PathVariable String groupName, @PathVariable String employeeId) {
        groupService.removeEmployeeFromGroup(groupName, employeeId);
    }

    @PutMapping("/{id}/name")
    public Groupp updateGroupName(@PathVariable Long id, @RequestBody AddEmployeeRequest addEmployeeRequest) {
        return groupService.updateGroupName(id, addEmployeeRequest);
    }


}
