package com.af.ems.EMS1.Service;

import com.af.ems.EMS1.Entity.Employee;
import com.af.ems.EMS1.Entity.PasswordResetToken;
import com.af.ems.EMS1.Exception.ResourceNotFoundException;
import com.af.ems.EMS1.Repository.EmployeeRepository;
import com.af.ems.EMS1.Repository.PasswordResetTokenRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class EmployeeService {
    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private PasswordResetTokenRepository passwordResetTokenRepository;

    @Autowired
    private EmailService emailService;


//    @Transactional
//    public Employee saveEmployee(Employee employee, MultipartFile photo) throws IOException {
//        if (photo != null && !photo.isEmpty()) {
//            employee.setPhotoData(photo.getBytes());
//        }
//        return employeeRepository.save(employee);
//    }
//    //this will handle both save and update





    @Transactional
    public Employee saveEmployee(Employee employee, MultipartFile photo) throws IOException {
        boolean isNewEmployee = (employee.getId() == null); // Check if the employee is new

        if (photo != null && !photo.isEmpty()) {
            employee.setPhotoData(photo.getBytes());
        }
        Employee savedEmployee = employeeRepository.save(employee);

        if (isNewEmployee) {
            // Generate token for new employee
            String token = UUID.randomUUID().toString();
            saveToken(employee, token);

            // Send email with reset link
            String resetLink = "http://localhost:3000/reset-password?token=" + token;
//            emailService.sendEmail(employee.getEmail(), "Set Your Password",
//                    "Click the link to set your password: " + resetLink);
            emailService.sendPasswordResetEmail(employee.getEmail(), resetLink);
        }

        return savedEmployee;
    }

    private void saveToken(Employee employee, String token) {
        PasswordResetToken resetToken = new PasswordResetToken();
        resetToken.setToken(token);
        resetToken.setEmail(employee.getEmail());
        resetToken.setExpiryDate(LocalDateTime.now().plusHours(24)); // Set token expiry time
        passwordResetTokenRepository.save(resetToken);
    }










    public Employee getEmployeeById(String employeeId) {
        return employeeRepository.findByEmployeeId(employeeId)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found with ID: " + employeeId));
    }

    public List<Employee> getAllEmployees() {
        return employeeRepository.findAll();
    }

    public Optional<Employee> getEmployeeById(Long id) {
        return employeeRepository.findById(id);
    }

    public void deleteEmployee(Long id) {
        Employee employee = employeeRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Employee not found for this id :: " + id));

        employeeRepository.delete(employee);
    }

    public List<String> getAllDepartments() {
        return employeeRepository.findAll().stream()
                .map(Employee::getDepartmentName)
                .distinct()
                .collect(Collectors.toList());
    }
}
