package com.af.ems.EMS1.Service;

import com.af.ems.EMS1.DTO.AddEmployeeRequest;
import com.af.ems.EMS1.Entity.Employee;
import com.af.ems.EMS1.Entity.GroupRequest;
import com.af.ems.EMS1.Entity.Groupp;
import com.af.ems.EMS1.Exception.ResourceNotFoundException;
import com.af.ems.EMS1.Repository.EmployeeRepository;
import com.af.ems.EMS1.Repository.GroupRepository;
import jakarta.transaction.Transactional;
import org.apache.catalina.Group;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class GroupService {
    @Autowired
    private GroupRepository groupRepository;

    @Autowired
    private EmployeeRepository employeeRepository;

    @Autowired
    private EmployeeService employeeService;

    @Transactional
    public Groupp createGroup(GroupRequest groupRequest) {
        Groupp group = new Groupp();
        group.setName(groupRequest.getName());
        group.setDescription(groupRequest.getDescription());

        List<Employee> employees = employeeRepository.findAllById(groupRequest.getEmployeeIds());
        group.setEmployees(employees);

        return groupRepository.save(group);
    }
    @Transactional
    public void addEmployeeToGroup(String employeeId, String groupName) {
        // Fetch the employee
        Employee employee = employeeService.getEmployeeById(employeeId);

        // Fetch the group (using Optional handling)
        Optional<Groupp> optionalGroup = groupRepository.findByName(groupName);
        if (optionalGroup.isPresent()) {
            Groupp group = optionalGroup.get();

            // Add the employee to the group
            List<Employee> employees = group.getEmployees();
            employees.add(employee);
            group.setEmployees(employees);

            // Save the updated group
            groupRepository.save(group);
        } else {
            // Handle error if group with given name does not exist
            throw new ResourceNotFoundException("Group not found with name: " + groupName);
        }
    }
    public List<Groupp> getAllGroups() {
        return groupRepository.findAll();
    }
    public Optional<Groupp> getGroupById(Long id) {
        return groupRepository.findById(id);
    }
    public Groupp updateGroup(Long id, GroupRequest groupRequest) {
        Groupp group = groupRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Group not found for this id :: " + id));

        group.setName(groupRequest.getName());
        group.setDescription(groupRequest.getDescription());

        List<Employee> employees = employeeRepository.findAllById(groupRequest.getEmployeeIds());
        group.setEmployees(employees);

        return groupRepository.save(group);
    }
    public void deleteGroup(Long id) {
        Groupp group = groupRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Group not found for this id :: " + id));

        groupRepository.delete(group);
    }
    public List<Employee> getEmployeesByGroupName(String groupName) {
        Groupp group = groupRepository.findByName(groupName)
                .orElseThrow(() -> new ResourceNotFoundException("Group not found with name: " + groupName));
        return group.getEmployees();
    }

    public void removeEmployeeFromGroup(String groupName, String employeeId) {
        Optional<Groupp> optionalGroup = groupRepository.findByName(groupName);
        if (optionalGroup.isPresent()) {
            Groupp group = optionalGroup.get();
            Employee employee = employeeService.getEmployeeById(employeeId);
            List<Employee> employees = group.getEmployees();

            if (employees.remove(employee)) {
                group.setEmployees(employees);
                groupRepository.save(group);
            } else {
                throw new ResourceNotFoundException("Employee not found in group: " + groupName);
            }
        } else {
            throw new ResourceNotFoundException("Group not found with name: " + groupName);
        }
    }

    public Groupp updateGroupName(Long id, AddEmployeeRequest addEmployeeRequest) {
        Groupp group = groupRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Group not found for this id :: " + id));

        group.setName(addEmployeeRequest.getGroupName());

        return groupRepository.save(group);
    }

}
