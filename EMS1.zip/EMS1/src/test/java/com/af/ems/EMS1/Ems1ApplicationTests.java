package com.af.ems.EMS1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ems1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
